#include <stdio.h>
#include <stdlib.h>
#define VALOR 8


int main(void){

    int opc = 0;

    int vet[VALOR];
    int num = 0;
    int cont = 0;
    int verif = 0;
    int pos = 0;
    int pesquisadechave = 0;

    do{


    printf("\n 1- Inserir valor\n");
    printf(" 2- Remover valor\n");
    printf(" 3- Pesquisar valor\n");
    printf(" 4- Sair\n\n");
    printf("Opcao desejada: ");
    scanf("%d", &opc);
    
     system("cls");

    switch(opc){

        case 1:{

            printf("\nDigite um numero: ");
            scanf("%d", &num);

            if(vet[num % 13] == 0){

			vet[ (num % 13) ] = num;
				
			break;
               	
        	}
        	
        	if(vet[num % 13] != 0){
        		
        		for(cont = (num % 13); cont <= VALOR; cont++){

                if(vet[cont] == 0){

                vet[cont] = num;
                verif = 1;

				break;

                }
        		
			}
			
				 if(verif == 0){
					
					for(cont = 0; cont <= VALOR; cont++){

                    if(vet[cont] == 0){

                    vet[cont] = num;
                            
					break;
							
                    }					
				
				}
					
			}
	
		}
			
    break;

    }

        case 2:{

        printf("\nDigite a pos para retirar: ");
        scanf("%d", &pos);

            vet[pos] = 0;

			for(cont = 0; cont <= VALOR; cont++){
				
			if( (vet[cont]) % 13 != vet[cont] ){
					
				if(vet[ (vet[cont]) % 13 ] == 0){
						
				vet[ (vet[cont]) % 13 ] = vet[cont];
				vet[cont] = 0;
						
				}
					
			}  
				
		}

        break;

		}

        case 3:{

           printf("\nDigite um numero para pesquisar: ");
           scanf("%d", &pesquisadechave);

           for(cont = 0; cont <= VALOR; cont++){

            if(vet[cont] == pesquisadechave){

            printf("\n\nO numero na pos (%d) do vet...", cont);
            getchar();
            getchar();
	                
					if( (pesquisadechave % 13) != cont){
	
	                    printf("\nNumero teve colis�o\n\n");
	                    system("pause");
	
	                }
	                
	                else{
	                	
	                	printf("\nNumero n�o teve colis�o!\n\n");
	                	system("pause");
	                	
					}
				
				}       
       		}
        }

    break;

    }

    }

    while(opc != 0);

	printf("\n");
	system("pause");
    return 0;
    
}
